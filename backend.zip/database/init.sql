-- database/init.sql
-- SlotWise Database Initialization Script
-- Run this file to create all tables and insert sample data

-- Create database
CREATE DATABASE IF NOT EXISTS slotwise;
USE slotwise;

-- Drop existing tables (careful in production!)
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS time_slots;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS users;

-- ============================================
-- TABLE: users
-- ============================================
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    avatar_url VARCHAR(255),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: services
-- ============================================
CREATE TABLE services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    duration_minutes INT NOT NULL,
    price DECIMAL(8,2) NOT NULL,
    image_url VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: time_slots
-- ============================================
CREATE TABLE time_slots (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_service_date (service_id, date),
    INDEX idx_available (is_available),
    UNIQUE KEY unique_slot (service_id, date, start_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: bookings
-- ============================================
CREATE TABLE bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    service_id INT NOT NULL,
    slot_id INT NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') NOT NULL DEFAULT 'pending',
    notes TEXT,
    cancelled_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    FOREIGN KEY (slot_id) REFERENCES time_slots(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_status (status),
    INDEX idx_slot (slot_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: notifications
-- ============================================
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    booking_id INT,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
    INDEX idx_user_read (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- SEED DATA
-- ============================================

-- Insert sample users
-- Password for all users: "password123"
-- Hash generated using bcrypt with salt rounds = 10
INSERT INTO users (name, email, password_hash, role) VALUES
('Admin User', 'admin@slotwise.com', '$2a$10$rKJ5EYqXZ4vK5H3L6YqXZ.kJ5EYqXZ4vK5H3L6YqXZ4vK5H3L6YqXO', 'admin'),
('John Doe', 'john@example.com', '$2a$10$rKJ5EYqXZ4vK5H3L6YqXZ.kJ5EYqXZ4vK5H3L6YqXZ4vK5H3L6YqXO', 'user'),
('Jane Smith', 'jane@example.com', '$2a$10$rKJ5EYqXZ4vK5H3L6YqXZ.kJ5EYqXZ4vK5H3L6YqXZ4vK5H3L6YqXO', 'user'),
('Mike Johnson', 'mike@example.com', '$2a$10$rKJ5EYqXZ4vK5H3L6YqXZ.kJ5EYqXZ4vK5H3L6YqXZ4vK5H3L6YqXO', 'user');

-- Insert sample services
INSERT INTO services (name, description, duration_minutes, price, is_active) VALUES
('Haircut', 'Professional haircut and styling service', 30, 25.00, TRUE),
('Hair Coloring', 'Full hair coloring service with premium products', 90, 75.00, TRUE),
('Beard Trim', 'Professional beard trimming and shaping', 15, 15.00, TRUE),
('Massage Therapy', 'Relaxing full body massage', 60, 80.00, TRUE),
('Manicure', 'Professional nail care and polish', 45, 35.00, TRUE),
('Pedicure', 'Foot care, massage, and nail polish', 60, 45.00, TRUE),
('Facial Treatment', 'Deep cleansing facial with moisturizing', 45, 55.00, TRUE),
('Consultation', 'Initial consultation for new clients', 20, 0.00, TRUE);

-- Insert time slots for next 7 days
-- This creates slots for Haircut service (service_id = 1)
-- Morning slots: 9:00 AM - 12:00 PM
-- Afternoon slots: 2:00 PM - 5:00 PM

-- Helper: Generate slots for today
SET @today = CURDATE();
SET @tomorrow = DATE_ADD(CURDATE(), INTERVAL 1 DAY);
SET @day2 = DATE_ADD(CURDATE(), INTERVAL 2 DAY);
SET @day3 = DATE_ADD(CURDATE(), INTERVAL 3 DAY);
SET @day4 = DATE_ADD(CURDATE(), INTERVAL 4 DAY);
SET @day5 = DATE_ADD(CURDATE(), INTERVAL 5 DAY);
SET @day6 = DATE_ADD(CURDATE(), INTERVAL 6 DAY);

-- Today's slots (Haircut - 30 min slots)
INSERT INTO time_slots (service_id, date, start_time, end_time, is_available, created_by) VALUES
(1, @today, '09:00:00', '09:30:00', TRUE, 1),
(1, @today, '09:30:00', '10:00:00', TRUE, 1),
(1, @today, '10:00:00', '10:30:00', TRUE, 1),
(1, @today, '10:30:00', '11:00:00', TRUE, 1),
(1, @today, '11:00:00', '11:30:00', TRUE, 1),
(1, @today, '11:30:00', '12:00:00', TRUE, 1),
(1, @today, '14:00:00', '14:30:00', TRUE, 1),
(1, @today, '14:30:00', '15:00:00', TRUE, 1),
(1, @today, '15:00:00', '15:30:00', TRUE, 1),
(1, @today, '15:30:00', '16:00:00', TRUE, 1),
(1, @today, '16:00:00', '16:30:00', TRUE, 1),
(1, @today, '16:30:00', '17:00:00', TRUE, 1);

-- Tomorrow's slots
INSERT INTO time_slots (service_id, date, start_time, end_time, is_available, created_by) VALUES
(1, @tomorrow, '09:00:00', '09:30:00', TRUE, 1),
(1, @tomorrow, '09:30:00', '10:00:00', TRUE, 1),
(1, @tomorrow, '10:00:00', '10:30:00', TRUE, 1),
(1, @tomorrow, '10:30:00', '11:00:00', TRUE, 1),
(1, @tomorrow, '11:00:00', '11:30:00', TRUE, 1),
(1, @tomorrow, '11:30:00', '12:00:00', TRUE, 1),
(1, @tomorrow, '14:00:00', '14:30:00', TRUE, 1),
(1, @tomorrow, '14:30:00', '15:00:00', TRUE, 1),
(1, @tomorrow, '15:00:00', '15:30:00', TRUE, 1),
(1, @tomorrow, '15:30:00', '16:00:00', TRUE, 1);

-- Massage slots (service_id = 4, 60 min slots) for tomorrow
INSERT INTO time_slots (service_id, date, start_time, end_time, is_available, created_by) VALUES
(4, @tomorrow, '09:00:00', '10:00:00', TRUE, 1),
(4, @tomorrow, '10:00:00', '11:00:00', TRUE, 1),
(4, @tomorrow, '11:00:00', '12:00:00', TRUE, 1),
(4, @tomorrow, '14:00:00', '15:00:00', TRUE, 1),
(4, @tomorrow, '15:00:00', '16:00:00', TRUE, 1);

-- Sample booking (John booked a haircut)
INSERT INTO bookings (user_id, service_id, slot_id, status, notes) VALUES
(2, 1, 1, 'confirmed', 'First time customer');

-- Mark that slot as unavailable
UPDATE time_slots SET is_available = FALSE WHERE id = 1;

-- Sample notification for John
INSERT INTO notifications (user_id, booking_id, message, type, is_read) VALUES
(2, 1, 'Your booking has been confirmed for today at 9:00 AM', 'booking_confirmed', FALSE);

-- ============================================
-- VERIFICATION QUERIES
-- ============================================
SELECT '==== DATABASE CREATED SUCCESSFULLY ====' as '';
SELECT 'Users created:' as '', COUNT(*) as count FROM users;
SELECT 'Services created:' as '', COUNT(*) as count FROM services;
SELECT 'Time slots created:' as '', COUNT(*) as count FROM time_slots;
SELECT 'Bookings created:' as '', COUNT(*) as count FROM bookings;
SELECT 'Notifications created:' as '', COUNT(*) as count FROM notifications;

-- Show admin credentials
SELECT '==== TEST CREDENTIALS ====' as '';
SELECT 'Admin Login:' as info, 'admin@slotwise.com' as email, 'password123' as password
UNION ALL
SELECT 'User Login:', 'john@example.com', 'password123'
UNION ALL
SELECT 'User Login:', 'jane@example.com', 'password123';

-- Note: The bcrypt hashes above are EXAMPLES
-- You need to generate real hashes by running:
-- node -e "console.log(require('bcryptjs').hashSync('password123', 10))"