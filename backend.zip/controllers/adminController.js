// controllers/adminController.js
const db = require('../config/db'); // ← THIS was missing

// ─────────────────────────────────────────────────────────────
// GET /api/admin/stats
// ─────────────────────────────────────────────────────────────
exports.getStats = async (req, res) => {
  try {
    console.log('📊 getStats: starting queries...');
    console.log('📊 Query 1: todayBookings');
    const [[{ todayBookings }]] = await db.query(
      `SELECT COUNT(*) AS todayBookings
       FROM bookings
       WHERE DATE(created_at) = CURDATE()`
    );

    console.log('📊 Query 2: pendingBookings');
    const [[{ pendingBookings }]] = await db.query(
      `SELECT COUNT(*) AS pendingBookings
       FROM bookings
       WHERE status = 'pending'`
    );

    console.log('📊 Query 3: totalBookings');
    const [[{ totalBookings }]] = await db.query(
      `SELECT COUNT(*) AS totalBookings FROM bookings`
    );

    console.log('📊 Query 4: totalRevenue');
    const [[{ totalRevenue }]] = await db.query(
      `SELECT COALESCE(SUM(s.price), 0) AS totalRevenue
       FROM bookings b
       JOIN services s ON b.service_id = s.id
       WHERE b.status IN ('confirmed', 'completed')`
    );

    console.log('📊 Query 5: popularServices');
    const [popularServices] = await db.query(
      `SELECT
         s.name,
         COALESCE(COUNT(b.id), 0) AS booking_count
       FROM services s
       LEFT JOIN bookings b
         ON b.service_id = s.id
        AND b.status != 'cancelled'
       GROUP BY s.id, s.name
       ORDER BY booking_count DESC
       LIMIT 5`
    );
    console.log('📊 All queries complete ✅');

    res.json({
      success: true,
      data: {
        todayBookings,
        pendingBookings,
        totalBookings,
        totalRevenue,
        popularServices, // [{ name: String, booking_count: Int }]
      },
    });
  } catch (error) {
    console.error('❌ getStats error:', error.message);
    console.error('❌ Full error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch stats' });
  }
};

// ─────────────────────────────────────────────────────────────
// GET /api/admin/bookings?status=pending&date=YYYY-MM-DD
// ─────────────────────────────────────────────────────────────
exports.getAllBookings = async (req, res) => {
  try {
    const { status, date } = req.query;

    let query = `
      SELECT
        b.id, b.status, b.notes, b.created_at,
        u.name  AS customerName,
        u.email AS customerEmail,
        s.name  AS serviceName,
        s.price,
        sl.date,
        sl.start_time,
        sl.end_time
      FROM bookings b
      JOIN users      u  ON b.user_id    = u.id
      JOIN services   s  ON b.service_id = s.id
      JOIN time_slots sl ON b.slot_id    = sl.id
      WHERE 1=1
    `;
    // ✅ FIXED: 'slots' → 'time_slots' (matches actual table name)

    const params = [];

    if (status) {
      query += ' AND b.status = ?';
      params.push(status);
    }
    if (date) {
      query += ' AND sl.date = ?';
      params.push(date);
    }

    query += ' ORDER BY sl.date DESC, sl.start_time ASC';

    // ✅ FIXED: db.query() instead of db.promise().query()
    const [bookings] = await db.query(query, params);
    res.json({ success: true, data: bookings });
  } catch (err) {
    console.error('getAllBookings error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch bookings' });
  }
};

// ─────────────────────────────────────────────────────────────
// PUT /api/admin/bookings/:id/status
// ─────────────────────────────────────────────────────────────
exports.updateBookingStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['pending', 'confirmed', 'completed', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status value' });
    }

    // Free the slot if cancelling so it becomes bookable again
    if (status === 'cancelled') {
      // ✅ FIXED: db.query() instead of db.promise().query()
      const [[booking]] = await db.query(
        'SELECT slot_id FROM bookings WHERE id = ?',
        [id]
      );
      if (booking) {
        // ✅ FIXED: 'slots' → 'time_slots'
        await db.query(
          'UPDATE time_slots SET is_available = 1 WHERE id = ?',
          [booking.slot_id]
        );
      }
    }

    // ✅ FIXED: db.query() instead of db.promise().query()
    const [result] = await db.query(
      'UPDATE bookings SET status = ? WHERE id = ?',
      [status, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    res.json({ success: true, message: `Booking status updated to ${status}` });
  } catch (err) {
    console.error('updateBookingStatus error:', err);
    res.status(500).json({ success: false, message: 'Failed to update booking status' });
  }
};